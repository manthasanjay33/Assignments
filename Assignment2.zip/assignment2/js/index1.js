function exampleswitch() {

      var myslider=document.getElementById("range");
      
      var val=document.getElementById("value");
      
      val.innerHTML=myslider.value;
      
      
      myslider.oninput=function(){
      
            val.innerHTML=this.value;
      }
      
}  

function exampleswitch1() {

      var myslider=document.getElementById("age");
      
      
      var val=document.getElementById("value1");
      
      val.innerHTML=myslider.value;
      
      
      myslider.oninput=function(){
      
            val.innerHTML=this.value;
      }
      
}  